# Kampania pelna Final

- Czas utworzenia (UTC): `2026-05-16T01:26:43.967069+00:00`
- Profil: `full`
- Backend zadany: `auto`
- Tryb benchmarkow: `standard`
- CPU threads | benchmarki: `12`
- CPU threads | real kernels: `12`
- CPU threads | Filip: `12`
- Backend GPU rozwiazany: `metal`
- Backend FEM rozwiazany: `metal`
- Kod wyjscia kampanii: `0`

## Kroki

### CPU microbenchmarks

- Status: `ok`
- Czas: `221.63242101669312` s
- Wynik: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/runs/20260515_114604__profile-full`
- Log: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/thesis_full/20260515_114604__full_thesis__profile-full__backend-metal/logs/cpu_benchmark.log`
- Workflow: `cpu_benchmark`

### GPU microbenchmarks

- Status: `ok`
- Czas: `51.74298286437988` s
- Wynik: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/runs/20260515_114946__profile-full`
- Log: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/thesis_full/20260515_114604__full_thesis__profile-full__backend-metal/logs/gpu_benchmark.log`
- Workflow: `gpu_benchmark`

### CPU real kernels

- Status: `ok`
- Czas: `316.467405796051` s
- Wynik: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/runs/20260515_115037__profile-full`
- Log: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/thesis_full/20260515_114604__full_thesis__profile-full__backend-metal/logs/cpu_real_kernels.log`
- Workflow: `cpu_real_kernels`

### GPU real kernels

- Status: `ok`
- Czas: `72.0881769657135` s
- Wynik: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/runs/20260515_115554__profile-full`
- Log: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/thesis_full/20260515_114604__full_thesis__profile-full__backend-metal/logs/gpu_real_kernels.log`
- Workflow: `gpu_real_kernels`

### FEM option validation

- Status: `ok`
- Czas: `95.32858109474182` s
- Wynik: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/fem_option_validation/20260515_115706_807379__fem_option_validation__backend-metal`
- Log: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/thesis_full/20260515_114604__full_thesis__profile-full__backend-metal/logs/fem_option_validation.log`
- Workflow: `fem_option_validation`

### Filip original portable sweep

- Status: `ok`
- Czas: `9504.364043712616` s
- Wynik: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/optimization/20260515_115842_367411__filip_original__backend-metal`
- Log: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/thesis_full/20260515_114604__full_thesis__profile-full__backend-metal/logs/filip_original_portable.log`
- Workflow: `filip_original`
- Optymalizator: `exhaustive_sweep`

### Filip autotuning (random search)

- Status: `ok`
- Czas: `14376.517181873322` s
- Wynik: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/optimization/20260515_143707__filip_autotune__backend-metal`
- Log: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/thesis_full/20260515_114604__full_thesis__profile-full__backend-metal/logs/filip_autotune.log`
- Workflow: `filip_autotune`
- Optymalizator: `random_search`

### Filip autotuning (firefly)

- Status: `ok`
- Czas: `25856.05615711212` s
- Wynik: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/optimization/20260515_183643__fem_parametric__backend-metal`
- Log: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/thesis_full/20260515_114604__full_thesis__profile-full__backend-metal/logs/filip_firefly.log`
- Workflow: `filip_firefly`
- Optymalizator: `firefly`

### Filip exact reference / replay

- Status: `ok`
- Czas: `4916.625730037689` s
- Wynik: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/optimization/20260516_014741_624378__filip_original__backend-metal__exact`
- Log: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/thesis_full/20260515_114604__full_thesis__profile-full__backend-metal/logs/filip_exact_reference.log`
- Workflow: `filip_original`
- Optymalizator: `exhaustive_sweep`

### Profiler correlation

- Status: `ok`
- Czas: `1028.3548259735107` s
- Wynik: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/optimization/20260516_014741_624378__filip_original__backend-metal__exact/profiler_correlation`
- Log: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/thesis_full/20260515_114604__full_thesis__profile-full__backend-metal/logs/profiler_correlation.log`
- Workflow: `profiler_correlation`

## Kluczowe artefakty

- `cpu_benchmark`: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/runs/20260515_114604__profile-full`
- `cpu_real_kernels`: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/runs/20260515_115037__profile-full`
- `fem_option_validation`: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/fem_option_validation/20260515_115706_807379__fem_option_validation__backend-metal`
- `filip_autotune`: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/optimization/20260515_143707__filip_autotune__backend-metal`
- `filip_exact_reference`: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/optimization/20260516_014741_624378__filip_original__backend-metal__exact`
- `filip_firefly`: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/optimization/20260515_183643__fem_parametric__backend-metal`
- `filip_original_portable`: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/optimization/20260515_115842_367411__filip_original__backend-metal`
- `gpu_benchmark`: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/runs/20260515_114946__profile-full`
- `gpu_real_kernels`: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/runs/20260515_115554__profile-full`
- `profiler_correlation`: `/Users/mateusznytko/Desktop/Praca/Doktorat/Testy/Testy_grudzien/apple_microbench_variant2_streamfix/Final/data/optimization/20260516_014741_624378__filip_original__backend-metal__exact/profiler_correlation`
