//QSS
//!!!!!!!!!!! TODO: SEPARATE GEO_DATA AND PDE_COEFF !!!!!!!!!!!!!!!!

//!!!!!!!!!!! TEST DIFFERENT CONFIGURATIONS OF SHARED / L1 MEMORY

//!!!!!!!!!!! LOOP UNROLLING = REGISTER BLOCKING FOR INNERMOST LOOPS ??????????

//----------------------------------------------------
// TWO MASTER SWITCHES (float<->double, work_group_size)
#define FLOAT
#ifdef FLOAT
  #define SCALAR float
  #define zero 0.0f
  #define one 1.0f
  #define two 2.0f
  #define half 0.5f
  #define one_fourth 0.25f
  #define one_sixth (0.16666666667f)
#else
  #define SCALAR double
  #define zero 0.0
  #define one 1.0
  #define two 2.0
  #define half 0.5
  #define one_fourth 0.25
  #define one_sixth (0.166666666666666667)
#endif

//#define WORK_GROUP_SIZE 16 // for XEON_PHI
#define WORK_GROUP_SIZE 64 // for GPUs
//#define WORK_GROUP_SIZE 8 // for CPUs
//----------------------------------------------------

#define WG_SIZE_JAC 64 //32*5

//----------------------------------------------------
// SEVERAL PROBLEM, ELEMENT AND APPROXIMATION DEPENDENT SWITCHES 
// (nr_exec_params, nreq, num_shap, num_gauss, num_geo_dofs
#define NR_EXEC_PARAMS 16  // size of array with execution parameters
// here: the smallest work-group for reading data is selected
// exec_params are read from global to shared memory and used when needed
// if shared memory resources are scarce this can be reduced

// FOR SCALAR PROBLEMS !!!!!!!!!!!!!!!!!!!!!
#define nreq 1
// FOR NS_SUPG PROBLEM !!!!!!!!!!!!!!!!!!!!!
//#define nreq 4

// FOR LINEAR PRISMS !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#define num_shap 40
#define num_gauss 48
#define num_geo_dofs 6

#define num_shap_pad 40
//#define weight_linear_prism (one_sixth)
//#define weight_gauss weight_linear_prism

#define NENTPT 20 //18

//#define nr_parts (int)ceil((double)(num_shap*num_shap)/(NENTPT*WORK_GROUP_SIZE)) //32

//#define OUTSIDE

#ifdef OUTSIDE 
	#define SIZE 7*18
#endif

// FOR LINEAR TETRAHEDRA !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//#define num_shap 4
//#define num_gauss 4
//#define num_geo_dofs 4
//#define weight_linear_tetra (one_fourth*one_sixth)
//#define weight_gauss weight_linear_tetra

#define num_dofs (num_shap*nreq)
#define EL_GEO_DAT_SIZE (3*num_geo_dofs)

// J_AND_DETJ_SIZE=10 - for NOJAC variants
//#define J_AND_DETJ_SIZE 10

// the number of coefficients sent for elements
// either coefficients constant for the whole element
// or different for every integration point
//#define LAPLACE
//#define TEST_NUMINT
//#define HEAT
#ifdef LAPLACE
  #define NR_COEFFS_SENT_PER_ELEMENT 0
  #define NR_COEFFS_SENT_PER_INT_POINT 1
  #define NR_COEFFS_IN_SM_CALCULATIONS num_gauss
#elif defined TEST_NUMINT
  #define NR_COEFFS_SENT_PER_ELEMENT 20
  #define NR_COEFFS_SENT_PER_INT_POINT 0
  #define NR_COEFFS_IN_SM_CALCULATIONS 20
#elif defined HEAT
  #define NR_COEFFS_SENT_PER_ELEMENT (num_dofs+1)
  #define NR_COEFFS_SENT_PER_INT_POINT 5
  #define NR_COEFFS_IN_SM_CALCULATIONS 20
#endif

#define NR_PDE_COEFFS_SENT (NR_COEFFS_SENT_PER_ELEMENT + NR_COEFFS_SENT_PER_INT_POINT*num_gauss)
//----------------------------------------------------


//----------------------------------------------------
// SWITCHES FOR DIFFERENT OPTIMIZATION OPTIONS !!!!!!!!!!!!!!!!!!!!!!!!

//load vector computing - not defined only for some tests
//#define LOAD_VEC_COMP

// COAL_READ - both PDE_COEFF and GEO_DATA are read in a coalesced way (using a single workspace)
// coalesced reading may be good for GPUs (requires large workspace and several barriers)
// (the workspace can be further used by GEO_DAT or PDE_COEFF or SHAPE_FUN or STIFF_MAT !!!)
#define COAL_READ

// coalesced writing requires host code to adapt to the order of data!!!
// coalesced writing should be switched on for GPUs
//#define COAL_WRITE

// COMPUTE_ALL_SHAPE_FUN_DER - to compute all shape functions and their derivatives
//                         before entering the loops over shape functions
#define COMPUTE_ALL_SHAPE_FUN_DER

//#define COUNT_OPER

// ********** THE SET OF OPTIONS FOR USING THE WORKSPACE IN SHARED MEMORY
// ********** AT MOST 1 SHOULD BE DEFINED !!!!!!!!!!!!!!!
// USE_WORKSPACE_FOR_PDE_COEFF - to use shared memory for pde_coeff during SM calculations
// otherwise - registers are used
//#define USE_WORKSPACE_FOR_PDE_COEFF

// USE_WORKSPACE_FOR_GEO_DATA - to use shared memory for geo_dat during SM calculations
// otherwise - registers are used
//#define USE_WORKSPACE_FOR_GEO_DATA


// USE_WORKSPACE_FOR_SHAPE_FUN - to use shared memory for shape functions 
//                               and their derivatives during SM calculations
// otherwise - registers are used
#define USE_WORKSPACE_FOR_SHAPE_FUN
//#define USE_WORKSPACE_FOR_JACOBIAN_DATA

//#define USE_WORKSPACE_FOR_SHAPE_FUN_REF

// USE_WORKSPACE_FOR_STIFF_MAT - to use shared memory for SM during SM calculations
// otherwise - registers are used
//#define USE_WORKSPACE_FOR_STIFF_MAT

// FOR EACH ARCHITECTURE PADDING SHOULD BE TESTED TO DETECT SHARED MEMORY BANK CONFLICTS
#define WORKSPACE_PADDING 0
#define PADDING WORKSPACE_PADDING

// THE END OF: SWITCHES FOR DIFFERENT OPTIMIZATION OPTIONS
//----------------------------------------------------

  __constant__ SCALAR *shpfun_ref = shp_fun_reference + 0;

__global__ void tmr_cuda_num_int_el(
	 int* execution_parameters,
	 //SCALAR* shpfun_ref, // shape functions on a reference element
	 SCALAR* el_data_in_coeff, // data for integration of NR_ELEMS_THIS_KERCALL elements
	 SCALAR* jac_dat,
	 SCALAR* stiff_mat_out // result of integration of NR_ELEMS_THIS_KERCALL elements
){

#ifdef COUNT_OPER
  SCALAR nr_oper=0.0;
#endif

  const int group_id = blockIdx.x;
  const int thread_id = threadIdx.x;

  //const int work_group_size = get_local_size(0);
  //const int nr_work_groups = get_num_groups(0);
//  if(group_id==1&&thread_id==0)
//    printf("Jestem!\n");
//----------------------------------------------------
// DEFINITIONS DEPENDENT ON OPTIMIZATION OPTIONS

#ifdef USE_WORKSPACE_FOR_PDE_COEFF
  #define WORKSPACE_SIZE_FOR_PDE_COEFF (NR_COEFFS_IN_SM_CALCULATIONS)
#else
  #define WORKSPACE_SIZE_FOR_PDE_COEFF 0
  //SCALAR pde_coeff[NR_COEFFS_IN_SM_CALCULATIONS];
  #ifdef LAPLACE
  SCALAR pde_coeff[num_shap];
  #endif
#endif

#ifdef USE_WORKSPACE_FOR_JACOBIAN_DATA
	#define WORKSPACE_SIZE_FOR_JACOBIAN_DATA num_gauss*10
  	__shared__ SCALAR workspace_jac[WORKSPACE_SIZE_FOR_JACOBIAN_DATA]; //
#endif

#ifdef USE_WORKSPACE_FOR_SHAPE_FUN
  #define WORKSPACE_SIZE_FOR_SHAPE_FUN (3*num_shap_pad)
#else
  #define WORKSPACE_SIZE_FOR_SHAPE_FUN 0
  #ifdef COMPUTE_ALL_SHAPE_FUN_DER
  SCALAR tab_fun_u_derx[num_shap];
  SCALAR tab_fun_u_dery[num_shap];
  SCALAR tab_fun_u_derz[num_shap];
  #endif
#endif

#ifdef USE_WORKSPACE_FOR_SHAPE_FUN_REF
  #define WORKSPACE_SIZE_FOR_SHAPE_FUN_REF (4*num_shap_pad*num_gauss)
  __shared__ SCALAR shpfun_ref_ws[WORKSPACE_SIZE_FOR_SHAPE_FUN_REF];
#endif

#ifdef USE_WORKSPACE_FOR_STIFF_MAT
  #define WORKSPACE_SIZE_FOR_STIFF_MAT (num_dofs*(num_dofs))
  __shared__ SCALAR stiff_mat[WORKSPACE_SIZE_FOR_STIFF_MAT];
#else
  #define WORKSPACE_SIZE_FOR_STIFF_MAT 0
  //padding
  //SCALAR stiff_mat[num_shap*num_shap];
  //SCALAR load_vec[num_shap];
#endif

#ifdef COAL_READ
  #define WORKSPACE_SIZE_FOR_READING NR_PDE_COEFFS_SENT
#else
  #define WORKSPACE_SIZE_FOR_READING 0
#endif

#define TMP_SIZE (WORKSPACE_SIZE_FOR_PDE_COEFF+WORKSPACE_SIZE_FOR_SHAPE_FUN)

#if (TMP_SIZE) > (WORKSPACE_SIZE_FOR_READING)
  #define WORKSPACE_SIZE ((TMP_SIZE+WORKSPACE_PADDING))
#else
  #define WORKSPACE_SIZE ((WORKSPACE_SIZE_FOR_READING+WORKSPACE_PADDING))
#endif

#if (WORKSPACE_SIZE) > 0
  __shared__ SCALAR workspace[WORKSPACE_SIZE]; //
#endif

 // __shared__ SCALAR temporary_vol;

// THE END OF: DEFINITIONS DEPENDENT ON OPTIMIZATION OPTIONS
//----------------------------------------------------


  // ASSUMPTION: one element = one thread

  //int nr_elems_per_thread = execution_parameters[0];
//  int nr_elems_this_kercall = execution_parameters[1];
  int nr_elems_per_wg = execution_parameters[2];

  int ielem,i;
  int offset;
  int aux_offset;
  int aux_offset1;

#ifdef USE_WORKSPACE_FOR_SHAPE_FUN_REF

  	  	  	//for(i=0;i<floor((double)((4*num_shap*num_gauss)/WORK_GROUP_SIZE));i++)
  	  	  	for(i=0;i<((4*num_shap*num_gauss)/WORK_GROUP_SIZE);i++)
  			{
  	  	  		shpfun_ref_ws[i*WORK_GROUP_SIZE+thread_id]=shpfun_ref[i*WORK_GROUP_SIZE+thread_id];
  //				if(element_index==0)
  //					printf("thread %d,i=%d - i*WORK_GROUP_SIZE+thread_id = %d\n",thread_id,i,i*WORK_GROUP_SIZE+thread_id);
  			}
//  			int res=num_gauss*10 - i*WORK_GROUP_SIZE;
//  			if(thread_id<res)
//  			{
//  				workspace_jac[i*WORK_GROUP_SIZE+thread_id]=jac_dat[offset+i*WORK_GROUP_SIZE+thread_id];
//  //				if(element_index==0)
//  //					printf("thread %d,i=%d - i*WORK_GROUP_SIZE+thread_id = %d\n",thread_id,i,i*WORK_GROUP_SIZE+thread_id);
//  			}

  			__syncthreads();



#endif



//-------------------------------------------------------------
//******************* loop over elements processed by a thread *********************
  for(ielem = 0; ielem < nr_elems_per_wg; ielem++){

    int element_index = group_id * nr_elems_per_wg + ielem;
    //int i;

//-------------------------------------------------------------
// ******************* READING INPUT DATA *********************

#ifdef COAL_READ

    offset = element_index * NR_PDE_COEFFS_SENT;

    //__syncthreads(); // !!!!!!!!!!!!!!!!!!!!!!

    if(thread_id<NR_PDE_COEFFS_SENT)
	{
    	workspace[thread_id] =	el_data_in_coeff[offset+thread_id];
	}

    //__syncthreads(); // !!!!!!!!!!!!!!!!!!!!!!

	#ifndef USE_WORKSPACE_FOR_PDE_COEFF

		offset=0;

		#ifdef LAPLACE

		pde_coeff[0]=workspace[offset+0];
		pde_coeff[1]=workspace[offset+1];
		pde_coeff[2]=workspace[offset+2];
		pde_coeff[3]=workspace[offset+3];
		pde_coeff[4]=workspace[offset+4];
		pde_coeff[5]=workspace[offset+5];

		#elif defined(TEST_NUMINT)
//wyrzucic przed ielem sprawdzic reuse
		SCALAR coeff00=workspace[offset+0];
		SCALAR coeff01=workspace[offset+1];
		SCALAR coeff02=workspace[offset+2];
		SCALAR coeff10=workspace[offset+3];
		SCALAR coeff11=workspace[offset+4];
		SCALAR coeff12=workspace[offset+5];
		SCALAR coeff20=workspace[offset+6];
		SCALAR coeff21=workspace[offset+7];
		SCALAR coeff22=workspace[offset+8];
		SCALAR coeff30=workspace[offset+9];
		SCALAR coeff31=workspace[offset+10];
		SCALAR coeff32=workspace[offset+11];
	//    SCALAR coeff03=workspace[offset+12];
	//    SCALAR coeff13=workspace[offset+13];
	//    SCALAR coeff23=workspace[offset+14];
		SCALAR coeff33=workspace[offset+15];
		SCALAR coeff04=workspace[offset+16];
		SCALAR coeff14=workspace[offset+17];
		SCALAR coeff24=workspace[offset+18];
		SCALAR coeff34=workspace[offset+19];

//		if(group_id==0 && ielem==0)
//		{
//			coeff
//		}


		#elif defined(HEAT)

		#endif

		//__syncthreads(); // !!!!!!!!!!!!!!!!!!!!!!

	#endif //use-workspace for pde coeff

	#ifdef USE_WORKSPACE_FOR_JACOBIAN_DATA
		//__syncthreads(); // !!!!!!!!!!!!!!!!!!!!!!
		#ifdef COAL_WRITE
			//int element_index = group_id * nr_elems_per_thread * WG_SIZE_JAC + ielem * WG_SIZE_JAC +thread_id ;
			//jac_dat[offset+i*WG_SIZE_JAC+thread_id];
			for(i=0;i<floor(num_gauss/WORK_GROUP_SIZE);i++)
			{
				workspace_jac[i*WORK_GROUP_SIZE+thread_id]=//?
			}
			int res=num_gauss-floor(num_gauss/WORK_GROUP_SIZE)*WORK_GROUP_SIZE;
			if(thread_id<res)
				workspace_jac[floor(num_gauss/WORK_GROUP_SIZE)*WORK_GROUP_SIZE+thread_id]=//?
		#else
			offset = element_index*WG_SIZE_JAC*10;

			for(i=0;i<floor((double)((10*num_gauss)/WORK_GROUP_SIZE));i++)
			{
				workspace_jac[i*WORK_GROUP_SIZE+thread_id]=jac_dat[offset+i*WORK_GROUP_SIZE+thread_id];
//				if(element_index==0)
//					printf("thread %d,i=%d - i*WORK_GROUP_SIZE+thread_id = %d\n",thread_id,i,i*WORK_GROUP_SIZE+thread_id);
			}
			int res=num_gauss*10 - i*WORK_GROUP_SIZE;
			if(thread_id<res)
			{
				workspace_jac[i*WORK_GROUP_SIZE+thread_id]=jac_dat[offset+i*WORK_GROUP_SIZE+thread_id];
//				if(element_index==0)
//					printf("thread %d,i=%d - i*WORK_GROUP_SIZE+thread_id = %d\n",thread_id,i,i*WORK_GROUP_SIZE+thread_id);
			}

			__syncthreads(); // !!!!!!!!!!!!!!!!!!!!!!

//			if(group_id==0 && thread_id==0 && element_index==81)
//			{
//				printf("wg=%d,elem_ind=%d,thread=%d\n",group_id,element_index,thread_id);
//				for(i=0;i<num_gauss*10;i++)
//				{
//					printf("workspace_jac[%d]=%lf\n",i,workspace_jac[i]);
//				}
//			}

		#endif
	#endif

#else // if not COAL_READ (i.e. only one or none of PDE_COEFF and GEO_DAT read in a coalsced way)

 //to do?

#endif // end if not COAL_READ

// ******* THE END OF: READING INPUT DATA *********************
//-------------------------------------------------------------

#if (WORKSPACE_SIZE) > 0
    __syncthreads(); // !!!!!!!!!!!!!!!!!!!!!!
#endif

#ifdef OUTSIDE

    SCALAR stiff_mat[SIZE];
    		for(i=0;i<SIZE;i++)
    			stiff_mat[i]=zero;

        	//		if(ielem==0&&group_id==0&&ipart<4)
    	//		printf("thread_id=%d,aux_offset=%d,ipart=%d,nr_parts=%d,jdof=%d,idof=%d\n",thread_id,aux_offset,ipart,nr_parts,jdof,idof);

    #ifdef LOAD_VEC_COMP
//    	SCALAR l;
//    	for(i=0;i<NENTPT;i++)
//    	{
//    			idof=(aux_offset-jdof*num_shap)+i;
//    			if (idof==jdof)
//    				l=zero;
//    	}
    #endif

#endif

//int ipart;
//    for(ipart=0;ipart<nr_parts;ipart++)
//    {

    	aux_offset = thread_id*NENTPT;
    	int jdof=aux_offset/num_shap;
    	//int idof=aux_offset%num_shap;
    	int idof=(aux_offset-jdof*num_shap);
if(jdof<num_shap)
{
    	//int idof;

#ifndef OUTSIDE

	#ifndef USE_WORKSPACE_FOR_STIFF_MAT
    	SCALAR stiff_mat[NENTPT];
		for(i=0;i<NENTPT;i++)
			stiff_mat[i]=zero;
	#else
		for(i=0;i<NENTPT;i++)
			stiff_mat[i*NENTPT+thread_id]=zero;
	#endif

  		//if(ielem==0&&group_id==0)
		//	printf("thread_id=%d,aux_offset=%d,jdof=%d,idof=%d\n",thread_id,aux_offset,jdof,idof);

#ifdef LOAD_VEC_COMP
	SCALAR l;
	for(i=0;i<NENTPT;i++)
	{
			idof=(aux_offset-jdof*num_shap)+i;
			if (idof==jdof)
				l=zero;
	}
#endif

#endif
//-------------------------------------------------------------
//******************** INITIALIZING SM AND LV ******************//

//******************** END OF: INITIALIZING SM AND LV ******************//
//-------------------------------------------------------------


//-------------------------------------------------------------
//************************* LOOP OVER INTEGRATION POINTS ************************//

    // in a loop over gauss points
    int igauss;

    for(igauss = 0; igauss < num_gauss; igauss++){

    	SCALAR temp1 = zero;
    	SCALAR temp2 = zero;
    	SCALAR temp3 = zero;
    	SCALAR temp4 = zero;
    	SCALAR temp5 = zero;
    	SCALAR temp6 = zero;
    	SCALAR temp7 = zero;
    	SCALAR jac[10];

		#ifndef USE_WORKSPACE_FOR_JACOBIAN_DATA

			#ifndef COAL_WRITE
    			offset=element_index*WG_SIZE_JAC*10+igauss*10;
    			for(i=0;i<10;i++)
    				jac[i]=jac_dat[offset+i];
    			//__syncthreads(); // !!!!!!!!!!!!!!!!!!!!!!
//    			if(igauss==0 && group_id==0 && thread_id==1 && element_index==79)
//				{
//					printf("wg=%d,elem_ind=%d,thread=%d,offset=%d\n",group_id,element_index,thread_id,offset);
//					for(i=0;i<10;i++)
//					{
//						printf("jac[%d]=%lf\n",i,jac[i]);
//						printf("jac_dat[%d]=%lf\n",offset+i,jac_dat[offset+i]);
//					}
//				}
			#else
    			//dorobic
			#endif

		#else
			#ifndef COAL_WRITE
    			for(i=0;i<10;i++)
    			    jac[i]=workspace_jac[igauss*10+i];
//    			if(igauss==0 && group_id==0 && thread_id==0 && element_index==81)
//				{
//					printf("wg=%d,elem_ind=%d,thread=%d,offset=%d\n",group_id,element_index,thread_id,offset);
//					for(i=0;i<10;i++)
//					{
//						printf("jac[%d]=%lf\n",i,jac[i]);
//						printf("workspace_jac[%d]=%lf\n",igauss*10+i,workspace_jac[igauss*10+i]);
//					}
//				}
			#else
    			//dorobic
			#endif
		#endif
//-------------------------------------------------------------
//***** SEPARATE COMPUTING OF ALL GLOBAL DERIVATIVES OF ALL SHAPE FUNCTIONS *****//


#ifdef COMPUTE_ALL_SHAPE_FUN_DER

 //************ loop for computing ALL shape function values at integration point **********//
	#ifdef USE_WORKSPACE_FOR_SHAPE_FUN_REF
		for(i=0;i<num_shap;i++)  //NENTPT loop
		{
			temp1 = shpfun_ref_ws[igauss*4*num_shap+num_shap+i];
			temp2 = shpfun_ref_ws[igauss*4*num_shap+2*num_shap+i];
			temp3 = shpfun_ref_ws[igauss*4*num_shap+3*num_shap+i];

			tab_fun_u_derx[i] = temp1*jac[0]+temp2*jac[3]+temp3*jac[6];
			tab_fun_u_dery[i] = temp1*jac[1]+temp2*jac[4]+temp3*jac[7];
			tab_fun_u_derz[i] = temp1*jac[2]+temp2*jac[5]+temp3*jac[8];
		}

	#else
		 #ifdef USE_WORKSPACE_FOR_SHAPE_FUN
			if(thread_id<num_shap)
			{
				// read proper values of shape functions and their derivatives
				//temp1 = shpfun_ref[igauss*4*num_shap+4*thread_id+1];
				//temp2 = shpfun_ref[igauss*4*num_shap+4*thread_id+2];
				//temp3 = shpfun_ref[igauss*4*num_shap+4*thread_id+3];
			//FK aligment
				temp1 = thread_id*0.1;//shpfun_ref[igauss*4*num_shap+num_shap+thread_id];
				temp2 = thread_id*0.2;//shpfun_ref[igauss*4*num_shap+2*num_shap+thread_id];
				temp3 = thread_id*0.3;//shpfun_ref[igauss*4*num_shap+3*num_shap+thread_id];

				//__syncthreads();

				workspace[3*thread_id]   = temp1*jac[0]+temp2*jac[3]+temp3*jac[6];
				workspace[3*thread_id+1] = temp1*jac[1]+temp2*jac[4]+temp3*jac[7];
				workspace[3*thread_id+2] = temp1*jac[2]+temp2*jac[5]+temp3*jac[8];

				//__syncthreads();
			#ifdef COUNT_OPER
				nr_oper += 15;
			#endif
			} // end loop over shape functions for which global derivatives were computed
		  #else  // if not USE_WORKSPACE_FOR_SHAPE_FUN

			for(i=0;i<num_shap;i++)  //NENTPT loop
			{
				temp1 = thread_id*0.1*i;//shpfun_ref[igauss*4*num_shap+num_shap+i];
				temp2 = thread_id*0.2*i;//shpfun_ref[igauss*4*num_shap+2*num_shap+i];
				temp3 = thread_id*0.3*i;//shpfun_ref[igauss*4*num_shap+3*num_shap+i];

				tab_fun_u_derx[i] = temp1*jac[0]+temp2*jac[3]+temp3*jac[6];
				tab_fun_u_dery[i] = temp1*jac[1]+temp2*jac[4]+temp3*jac[7];
				tab_fun_u_derz[i] = temp1*jac[2]+temp2*jac[5]+temp3*jac[8];
			}

		  #endif // end if not USE_WORKSPACE_FOR_SHAPE_FUN

			  __syncthreads();
	#endif //not use workspace for shape fun ref

#endif // end if COMPUTE_ALL_SHAPE_FUN_DER

//*** THE END OF: SEPARATE COMPUTING OF ALL GLOBAL DERIVATIVES OF ALL SHAPE FUNCTIONS ***//
//-------------------------------------------------------------


//-------------------------------------------------------------
//***** SUBSTITUTING ACTUAL COEFFICIENTS FOR SM AND LV CALCULATIONS *****//

#ifdef USE_WORKSPACE_FOR_PDE_COEFF


  #ifdef LAPLACE

      // offset for reading data
      offset=thread_id*(NR_PDE_COEFFS_SENT);

      SCALAR coeff03 = workspace[offset+igauss];

  #endif // end if LAPLACE

      // offset for computations
      offset=thread_id*(NR_COEFFS_IN_SM_CALCULATIONS);

#else // if not USE_WORKSPACE_FOR_PDE_COEFF

  #ifdef LAPLACE

      //SCALAR coeff03 = pde_coeff[igauss]; // DOES NOT WORK FOR AMD !!!!!!!!!
      SCALAR coeff03 = 0.0;
      switch(igauss){
      case 0:
	coeff03 = pde_coeff[0];
	break;
      case 1:
	coeff03 = pde_coeff[1];
	break;
      case 2:
	coeff03 = pde_coeff[2];
	break;
      case 3:
	coeff03 = pde_coeff[3];
	break;
      case 4:
	coeff03 = pde_coeff[4];
 	break;
      case 5:
	coeff03 = pde_coeff[5];
	break;
      }

  #endif // end if LAPLACE

#endif // end if not USE_WORKSPACE_FOR_PDE_COEFF

//*** THE END OF: SUBSTITUTING ACTUAL COEFFICIENTS FOR SM AND LV CALCULATIONS ***//
//-------------------------------------------------------------


//-------------------------------------------------------------
//********************* first loop over shape functions ***********************//

//printf("jdof")
//      if(jdof<num_shap)
//      {

//-------------------------------------------------------------
//****** SUBSTITUTING OR COMPUTING GLOBAL DERIVATIVES OF IDOF SHAPE FUNCTION ******//

#ifdef COMPUTE_ALL_SHAPE_FUN_DER

  #ifdef USE_WORKSPACE_FOR_SHAPE_FUN
//__syncthreads();
	  //SCALAR shp_fun_u = shpfun_ref[igauss*4*num_shap+4*jdof];
	  //FK aligment
	  SCALAR shp_fun_u = thread_id*0.4;//shpfun_ref[igauss*4*num_shap+jdof];
	  SCALAR fun_u_derx = workspace[3*jdof];
	  SCALAR fun_u_dery = workspace[3*jdof+1];
	  SCALAR fun_u_derz = workspace[3*jdof+2];
          //__syncthreads();
  #else // if not USE_WORKSPACE_FOR_SHAPE_FUN

	  // read proper values of shape functions and their derivatives
          SCALAR shp_fun_u = thread_id*0.4; //shpfun_ref[igauss*4*num_shap+jdof];  // ref_ws if USE_WORKSPACE_FOR_SHAPE_FUN_REF
          SCALAR fun_u_derx = tab_fun_u_derx[jdof];
          SCALAR fun_u_dery = tab_fun_u_dery[jdof];
          SCALAR fun_u_derz = tab_fun_u_derz[jdof];

  #endif // end if not USE_SHAPE_FUN_WORKSPACE

#else // if not COMPUTE_ALL_SHAPE_FUN_DER

	  // read proper values of shape functions and their derivatives
	  SCALAR shp_fun_u = shpfun_ref[igauss*4*num_shap+jdof];
	  temp1 = shpfun_ref[igauss*4*num_shap+num_shap+jdof];
	  temp2 = shpfun_ref[igauss*4*num_shap+2*num_shap+jdof];
	  temp3 = shpfun_ref[igauss*4*num_shap+3*num_shap+jdof];

	  // compute derivatives wrt global coordinates
	  // 15 operations
	  SCALAR fun_u_derx = temp1*jac[0] + temp2*jac[3] + temp3*jac[6];
	  SCALAR fun_u_dery = temp1*jac[1] + temp2*jac[4] + temp3*jac[7];
	  SCALAR fun_u_derz = temp1*jac[2] + temp2*jac[5] + temp3*jac[8];

  #ifdef COUNT_OPER
	  nr_oper += 15; // after optimization
	  // total: 13+5+18*num_geo_dofs+15+36+15*num_shap = 177+90 = 267 (for prisms)
  #endif

#endif // end if not COMPUTE_ALL_SHAPE_FUN_DER

//*** THE END OF: SUBSTITUTING OR COMPUTING GLOBAL DERIVATIVES OF IDOF SHAPE FUNCTION ***//
//-------------------------------------------------------------

//-------------------------------------------------------------
//*** ACTUAL INTERMEDIATE CALCULATIONS FOR IDOF SHAPE FUNCTION ***//

#ifdef LAPLACE

	  temp4=fun_u_derx;
	  temp5=fun_u_dery;
	  temp6=fun_u_derz;

#elif defined(TEST_NUMINT)

  #ifdef USE_WORKSPACE_FOR_PDE_COEFF

	  temp4 = workspace[offset+0]  * fun_u_derx +
	          workspace[offset+1]  * fun_u_dery +
	          workspace[offset+2]  * fun_u_derz;
	 // +       workspace[offset+12] * shp_fun_u ;

	  temp5 = workspace[offset+3]  * fun_u_derx +
	          workspace[offset+4]  * fun_u_dery +
	          workspace[offset+5]  * fun_u_derz;
	  //+      workspace[offset+13] * shp_fun_u;

	  temp6 = workspace[offset+6]  * fun_u_derx +
	          workspace[offset+7]  * fun_u_dery +
	          workspace[offset+8]  * fun_u_derz ;
	  //+      workspace[offset+14] * shp_fun_u;

	  temp7 = workspace[offset+9]  * fun_u_derx +
	          workspace[offset+10] * fun_u_dery +
	          workspace[offset+11] * fun_u_derz +
	          workspace[offset+15] * shp_fun_u;

  #else // if not USE_WORKSPACE_FOR_PDE_COEFF

	  temp4 = coeff00*fun_u_derx + coeff01*fun_u_dery + coeff02*fun_u_derz; //+ coeff03*shp_fun_u;
	  temp5 = coeff10*fun_u_derx + coeff11*fun_u_dery + coeff12*fun_u_derz; //+ coeff13*shp_fun_u;
	  temp6 = coeff20*fun_u_derx + coeff21*fun_u_dery + coeff22*fun_u_derz; //+ coeff23*shp_fun_u;
	  temp7 = coeff30*fun_u_derx + coeff31*fun_u_dery + coeff32*fun_u_derz + coeff33*shp_fun_u;

  #endif // if not USE_WORKSPACE_FOR_PDE_COEFF

  #ifdef COUNT_OPER
	  nr_oper += 5*4+2;
	#endif

#elif defined(HEAT)

#endif

//*** THE END OF: ACTUAL INTERMEDIATE CALCULATIONS FOR IDOF SHAPE FUNCTION ***//
//-------------------------------------------------------------

	  for(i=0;i<NENTPT;i++)  //NENTPT loop
	  {
	  	idof=(aux_offset-jdof*num_shap)+i;
	  	//idof=aux_offset%num_shap+i;
//-------------------------------------------------------------
//*** ACTUAL CALCULATIONS FOR LOAD VECTOR (AND IDOF SHAPE FUNCTION) ***//

#ifdef LOAD_VEC_COMP

	  if(idof==jdof)
	  {

  #ifdef USE_WORKSPACE_FOR_STIFF_MAT

 	  workspace[thread_id*(num_dofs*(num_dofs+1)+PADDING)+num_dofs*num_dofs+idof] += (

  #else

	  l += (

  #endif

  #ifdef LAPLACE

			     coeff03 * shp_fun_u

  #elif defined(TEST_NUMINT)

    #ifdef USE_WORKSPACE_FOR_PDE_COEFF

			     workspace[offset+16] * fun_u_derx +
			     workspace[offset+17] * fun_u_dery +
			     workspace[offset+18] * fun_u_derz +
			     workspace[offset+19] * shp_fun_u

    #else // if not USE_WORKSPACE_FOR_PDE_COEFF

			     coeff04 * fun_u_derx +
			     coeff14 * fun_u_dery +
			     coeff24 * fun_u_derz +
			     coeff34 * shp_fun_u


    #endif // end if not USE_WORKSPACE_FOR_PDE_COEFF

  #elif defined(HEAT)

  #endif

			     ) * jac[9];

  #ifdef COUNT_OPER
    #ifdef LAPLACE

	  nr_oper += 3;

    #elif defined(TEST_NUMINT)

	  nr_oper += 9;

    #elif defined(HEAT)

    #endif

  #endif

	  }//end idof==jdof

#endif // end if computing RHS vector

//*** THE END OF: ACTUAL CALCULATIONS FOR LOAD VECTOR (AND IDOF SHAPE FUNCTION) ***//
//-------------------------------------------------------------

//-------------------------------------------------------------
// ************************* second loop over shape functions ****************************//

//-------------------------------------------------------------
//****** SUBSTITUTING OR COMPUTING GLOBAL DERIVATIVES OF JDOF SHAPE FUNCTION ******//

#ifdef COMPUTE_ALL_SHAPE_FUN_DER

  #ifdef USE_WORKSPACE_FOR_SHAPE_FUN
	  //__syncthreads();
	  //SCALAR shp_fun_v = shpfun_ref[igauss*4*num_shap+4*idof];
//FK aligment
	  SCALAR shp_fun_v = thread_id*0.5;//shpfun_ref[igauss*4*num_shap+idof];
	  SCALAR fun_v_derx = workspace[3*idof];
	  SCALAR fun_v_dery = workspace[3*idof+1];
	  SCALAR fun_v_derz = workspace[3*idof+2];
	  //__syncthreads();

  #else // if not USE_WORKSPACE_FOR_SHAPE_FUN

	  SCALAR shp_fun_v = thread_id*0.5;//shpfun_ref[igauss*4*num_shap+idof]; //ref_ws if USE_WORKSPACE_FOR_SHAPE_FUN_REF
	  SCALAR fun_v_derx = tab_fun_u_derx[idof];
	  SCALAR fun_v_dery = tab_fun_u_dery[idof];
	  SCALAR fun_v_derz = tab_fun_u_derz[idof];

  #endif // end if not USE_WORKSPACE_FOR_SHAPE_FUN

#else // if not COMPUTE_ALL_SHAPE_FUN_DER

	// read proper values of shape functions and their derivatives
	SCALAR shp_fun_v = shpfun_ref[igauss*4*num_shap+idof];;
	temp1 = shpfun_ref[igauss*4*num_shap+num_shap+idof];
	temp2 = shpfun_ref[igauss*4*num_shap+2*num_shap+idof];
	temp3 = shpfun_ref[igauss*4*num_shap+3*num_shap+idof];

	// compute derivatives wrt global coordinates
	// 15 operations
	SCALAR fun_v_derx = temp1*jac[0] + temp2*jac[3] + temp3*jac[6];
	SCALAR fun_v_dery = temp1*jac[1] + temp2*jac[4] + temp3*jac[7];
	SCALAR fun_v_derz = temp1*jac[2] + temp2*jac[5] + temp3*jac[8];

  #ifdef COUNT_OPER
	nr_oper += 15;
  #endif

#endif // end if not COMPUTE_ALL_SHAPE_FUN_DER

//*** THE END OF: SUBSTITUTING OR COMPUTING GLOBAL DERIVATIVES OF IDOF SHAPE FUNCTION ***//
//-------------------------------------------------------------

//-------------------------------------------------------------
//********* ACTUAL FINAL CALCULATIONS FOR SM ENTRY  *********//

#ifdef USE_WORKSPACE_FOR_STIFF_MAT

	stiff_mat[i*NENTPT+thread_id] += (

#else
	#ifdef OUTSIDE
		stiff_mat[ipart*NENTPT+i] += (
	#else
		stiff_mat[i] += (
	#endif

#endif

#ifdef LAPLACE

      	    temp4 * fun_v_derx +
       	    temp5 * fun_v_dery +
       	    temp6 * fun_v_derz

#elif defined(TEST_NUMINT)

      	    temp4 * fun_v_derx +
       	    temp5 * fun_v_dery +
       	    temp6 * fun_v_derz +
       	    temp7 * shp_fun_v

#elif defined(HEAT)

      	    temp4 * fun_v_derx +
       	    temp5 * fun_v_dery +
       	    temp6 * fun_v_derz +
       	    temp7 * shp_fun_v

#endif

					    ) * jac[9];

#ifdef COUNT_OPER
  #ifdef LAPLACE
	nr_oper += 7;
  #elif defined(TEST_NUMINT)
	nr_oper += 9;
  #elif defined(HEAT)

  #endif
#endif

	//stiff_mat[i]=jdof*1000+idof;
	//barrier(CLK_LOCAL_MEM_FENCE);

//*** THE END OF: ACTUAL FINAL CALCULATIONS FOR SM ENTRY  ***//
//-------------------------------------------------------------
	//if(group_id==0 && ielem==0 && jdof==74 && idof==24)
	//{
	  //printf("igauss=%d, thread_id=%d, idof=%d, jdof=%d, temp4=%f,fun_v_derx=%f,temp5=%f,fun_v_dery=%f,temp6=%f,fun_v_derz=%f,temp7=%f,shp_fun_v=%f, vol=%f \n",igauss, thread_id,idof,jdof, temp4,fun_v_derx,temp5,fun_v_dery,temp6,fun_v_derz,temp7,shp_fun_v,jac[9]);
	  //printf("igauss=%d, thread_id=%d, idof=%d, jdof=%d, stiff_mat[%d]=%f \n",igauss, thread_id,idof,jdof,i,stiff_mat[i]);
	  //printf("igauss=%d, stiff_mat[%d]=%lf\n",igauss,idof2*num_shap_org+jdof,stiff_mat[idof2*num_shap_org+jdof]);
	//}
//			}

//	}//jdof


//        if(igauss==148 && group_id==0 && ielem==0)
//    	{
//    	  for(idof=0;idof<256;idof++)
//    		printf("stiff_mat[%d]=%lf\n",idof,stiff_mat[idof]);
//    	}


//******* THE END OF: first loop over shape functions *******//
//-------------------------------------------------------------

      }//idof//nentpt

//******* THE END OF: second loop over shape functions *******//
//-------------------------------------------------------------

//      if(igauss==0 && group_id==0 && ielem==0)
//  	{
//  	  for(idof=0;idof<256;idof++)
//  		printf("stiff_mat[%d]=%lf\n",idof,stiff_mat[idof]);
//  	}

      //}//if jdofs


    }//gauss

#ifndef OUTSIDE

 //   aux_offset1 = (group_id*nr_elems_per_wg+ielem)*(num_shap*num_shap+num_shap)+ipart*WORK_GROUP_SIZE*NENTPT;
    aux_offset1 = (group_id*nr_elems_per_wg+ielem)*(num_shap*num_shap+num_shap);
	//aux_offset = 0;
    //if(group_id<2 && ielem<2 && ipart<2)
//	{
//
//		printf("group_id=%d,ielem=%d,ipart=%d, aux_offset=%d,thread_id=%d,idof=%d,jdof=%d\n",group_id,ielem,ipart,aux_offset,thread_id,idof,jdof);
//	}
//    if(jdof<num_shap)
//          {
    //__syncthreads();
#ifdef USE_WORKSPACE_FOR_STIFF_MAT
	for(i=0;i<NENTPT;i++)
	{
		//idof=(aux_offset-jdof*num_shap)+i;
		//stiff_mat_out[aux_offset+i+(thread_id*NENTPT)] = stiff_mat[i];//jdof*1000+idof;//stiff_mat[i];
		stiff_mat_out[aux_offset1+i*NENTPT+thread_id] = stiff_mat[i*NENTPT+thread_id];//jdof*1000+idof;//stiff_mat[i];
		//idof=(aux_offset-jdof*num_shap)+i;
		//stiff_mat_out[jdof*num_shap+idof]=stiff_mat[i];
		//barrier(CLK_GLOBAL_MEM_FENCE);
	}


#else
    for(i=0;i<NENTPT;i++)
    {
    	//idof=(aux_offset-jdof*num_shap)+i;
    	//stiff_mat_out[aux_offset+i+(thread_id*NENTPT)] = stiff_mat[i];//jdof*1000+idof;//stiff_mat[i];
    	stiff_mat_out[aux_offset1+i*NENTPT+thread_id] = stiff_mat[i];//jdof*1000+idof;//stiff_mat[i];
    	//idof=(aux_offset-jdof*num_shap)+i;
    	//stiff_mat_out[jdof*num_shap+idof]=stiff_mat[i];
    	//barrier(CLK_GLOBAL_MEM_FENCE);
    }
#endif
	#ifdef LOAD_VEC_COMP

	 aux_offset = (group_id*nr_elems_per_wg+ielem)*(num_shap*num_shap+num_shap);

	    if(idof==jdof)
	    {
	    	stiff_mat_out[aux_offset+num_shap*num_shap+thread_id] = l;
	    }


	#endif

	    //__syncthreads();
#endif

    //barrier(CLK_GLOBAL_MEM_FENCE);
    //__syncthreads();

}//end if jdof

//barrier(CLK_GLOBAL_MEM_FENCE);
//__syncthreads();
//    }//end ipart

// ******** THE END OF: loop over integration points ********//
//-------------------------------------------------------------

#ifdef OUTSIDE

	//tu zapis!!
	    aux_offset = (group_id*nr_elems_per_wg+ielem)*(num_shap*num_shap+num_shap);
		//aux_offset = 0;
	    //if(group_id<2 && ielem<2 && ipart<2)
	//	{
	//
	//		printf("group_id=%d,ielem=%d,ipart=%d, aux_offset=%d,thread_id=%d,idof=%d,jdof=%d\n",group_id,ielem,ipart,aux_offset,thread_id,idof,jdof);
	//	}
	//    if(jdof<num_shap)
	//          {


	    for(i=0;i<SIZE;i++)
	    {
	    	//idof=(aux_offset-jdof*num_shap)+i;
	    	//stiff_mat_out[aux_offset+i+(thread_id*NENTPT)] = stiff_mat[i];//jdof*1000+idof;//stiff_mat[i];
	    	stiff_mat_out[aux_offset+i*SIZE+thread_id] = stiff_mat[i];//jdof*1000+idof;//stiff_mat[i];
	    	//idof=(aux_offset-jdof*num_shap)+i;
	    	//stiff_mat_out[jdof*num_shap+idof]=stiff_mat[i];
	    	//barrier(CLK_GLOBAL_MEM_FENCE);
	    }

	#ifdef LOAD_VEC_COMP

	 aux_offset = (group_id*nr_elems_per_wg+ielem)*(num_shap*num_shap+num_shap);

	    if(idof==jdof)
	    {
	    	stiff_mat_out[aux_offset+num_shap*num_shap+thread_id] = l;
	    }


	#endif
#endif



  } // the end of loop over elements

// ************* THE END OF: LOOP OVER ELEMENTS *************//
//-------------------------------------------------------------

  //stiff_mat_out[0] = 2;
#ifdef COUNT_OPER

  if(group_id==0)
  	  stiff_mat_out[thread_id] = nr_oper;

#endif


};


__global__ void tmr_cuda_prepare_jacobian_data(
		int* execution_parameters,
		SCALAR* gauss_dat,
		SCALAR* geo_in,
		SCALAR* jac_dat
){

  const int group_id = blockIdx.x;
  const int thread_id = threadIdx.x;

  //const int work_group_size = get_local_size(0);
  //const int nr_work_groups = get_num_groups(0);

//----------------------------------------------------
// DEFINITIONS DEPENDENT ON OPTIMIZATION OPTIONS

#ifdef USE_WORKSPACE_FOR_GEO_DATA
  #define WORKSPACE_SIZE_FOR_GEO_DATA (3*num_geo_dofs)
#else
  #define WORKSPACE_SIZE_FOR_GEO_DATA 0
  SCALAR geo_dat[3*num_geo_dofs];
#endif

#ifdef COAL_READ
  #define WORKSPACE_SIZE_FOR_READING_J (3*num_geo_dofs)
#else
  #define WORKSPACE_SIZE_FOR_READING_J 0
#endif

#define TMP_SIZE_J (WORKSPACE_SIZE_FOR_GEO_DATA)

#if (TMP_SIZE_J) > (WORKSPACE_SIZE_FOR_READING_J)
  #define WORKSPACE_SIZE_J ((TMP_SIZE_J+WORKSPACE_PADDING)*WG_SIZE_JAC)
#else
  #define WORKSPACE_SIZE_J ((WORKSPACE_SIZE_FOR_READING_J+WORKSPACE_PADDING)*WG_SIZE_JAC)
#endif

#if (WORKSPACE_SIZE_J) > 0
  __shared__ SCALAR workspace[WORKSPACE_SIZE_J]; //
#endif

// THE END OF: DEFINITIONS DEPENDENT ON OPTIMIZATION OPTIONS
//----------------------------------------------------

  // ASSUMPTION: one element = one thread

  int nr_elems_per_thread = execution_parameters[0];
//  int nr_elems_this_kercall = execution_parameters[1];

  int ielem;
  int offset;

//-------------------------------------------------------------
//******************* loop over elements processed by a thread *********************
  for(ielem = 0; ielem < nr_elems_per_thread; ielem++){

	int element_index = group_id * nr_elems_per_thread * WG_SIZE_JAC +
											   ielem * WG_SIZE_JAC +
											   	   	   	   	   thread_id ;
	int i;


//-------------------------------------------------------------
// ******************* READING INPUT DATA *********************

#ifdef COAL_READ

    // after rewriting PDE_COEFF to registers we read GEO_DATA to workspace
    offset = (element_index-thread_id)*(EL_GEO_DAT_SIZE);
    __syncthreads();
    // TRY TO UNROLL THIS LOOP TO INCREASE MEMORY PARALLELISM !!!
    for(i = 0; i < EL_GEO_DAT_SIZE; i++){

      workspace[i*WG_SIZE_JAC+thread_id] =
	                         geo_in[offset+i*WG_SIZE_JAC+thread_id];
	// TODO !!!!
	// el_data_in_geo[offset+i*WORK_GROUP_SIZE+thread_id];

    }
    __syncthreads();

	#ifndef USE_WORKSPACE_FOR_GEO_DATA

		  // we rewrite geo_data to registers
		  offset=thread_id*EL_GEO_DAT_SIZE;

		  for(i=0;i<num_geo_dofs;i++){

			geo_dat[3*i] = workspace[offset+3*i];  //node coor
			geo_dat[3*i+1] = workspace[offset+3*i+1];
			geo_dat[3*i+2] = workspace[offset+3*i+2];

		  }
	#endif

		  __syncthreads();

#else //if not coal read

	#ifdef USE_WORKSPACE_FOR_GEO_DATA

	  offset = (element_index-thread_id)*(EL_GEO_DAT_SIZE);

	  //__syncthreads(); // I don't know why but without barrier here, one per ten runs gives bad results

	  // TRY TO UNROLL THIS LOOP TO INCREASE MEMORY PARALLELISM !!!
	  for(i = 0; i < EL_GEO_DAT_SIZE; i++){

		workspace[i*WG_SIZE_JAC+thread_id] =
					  el_data_in[offset+i*WG_SIZE_JAC+thread_id];
		// TODO !!!!!!!!!
		// el_data_in_geo[offset+i*WORK_GROUP_SIZE+thread_id];

	  }

	#else // if not USE_WORKSPACE_FOR_GEO_DATA

	  // we read geo data to registers
	  offset = (element_index)*(EL_GEO_DAT_SIZE);

	  // TRY TO UNROLL THIS LOOP TO INCREASE MEMORY PARALLELISM !!!
	  for(i = 0; i < EL_GEO_DAT_SIZE; i++){

		geo_dat[i] = el_data_in[offset+i];
		// TODO !!!!!!!!!
		// geo_dat[i] = el_data_in_geo[offset+i];

	  }

	#endif  // if not USE_WORKSPACE_FOR_GEO_DATA

#endif // end if not COAL_READ


// ******* THE END OF: READING INPUT DATA *********************
//-------------------------------------------------------------

#if (WORKSPACE_SIZE) > 0
    __syncthreads(); // !!!!!!!!!!!!!!!!!!!!!!
#endif


//-------------------------------------------------------------
//************************* LOOP OVER INTEGRATION POINTS ************************//

    // in a loop over gauss points
    int igauss;
//    int idof, jdof;
    for(igauss = 0; igauss < num_gauss; igauss++){

      // integration data read from cached constant or shared  memory
      SCALAR daux = gauss_dat[4*igauss];
      SCALAR faux = gauss_dat[4*igauss+1];
      SCALAR eaux = gauss_dat[4*igauss+2];
      SCALAR vol = gauss_dat[4*igauss+3]; // vol = weight
      //SCALAR vol = weight_gauss; // vol = weight CONSTANT FOR LINEAR PRISM!!!
//-------------------------------------------------------------
//************************* JACOBIAN TERMS CALCULATIONS *************************//

      // when geometrical shape functions are not necessary
      // (only derivatives are used for Jacobian calculations)
      SCALAR temp1 = zero;
      SCALAR temp2 = zero;
      SCALAR temp3 = zero;
      SCALAR temp4 = zero;
      SCALAR temp5 = zero;
      SCALAR temp6 = zero;
      SCALAR temp7 = zero;
      SCALAR temp8 = zero;
      SCALAR temp9 = zero;

      SCALAR jac[10];
      for(i=0;i<10;i++)
    	  jac[i]=zero;
      // derivatives of geometrical shape functions
      { // block to indicate the scope of jac_data

        // derivatives of geometrical shape functions are stored in jac_data
	SCALAR jac_data[3*num_geo_dofs];
	jac_data[0] = -(one-eaux)*half;
	jac_data[1] =  (one-eaux)*half;
	jac_data[2] =  zero;
	jac_data[3] = -(one+eaux)*half;
	jac_data[4] =  (one+eaux)*half;
	jac_data[5] =  zero;
	jac_data[6] = -(one-eaux)*half;
	jac_data[7] =  zero;
	jac_data[8] =  (one-eaux)*half;
	jac_data[9] = -(one+eaux)*half;
	jac_data[10] =  zero;
	jac_data[11] =  (one+eaux)*half;
	jac_data[12] = -(one-daux-faux)*half;
	jac_data[13] = -daux*half;
	jac_data[14] = -faux*half;
	jac_data[15] =  (one-daux-faux)*half;
	jac_data[16] =  daux*half;
	jac_data[17] =  faux*half;

	/* Jacobian matrix J */
#ifdef USE_WORKSPACE_FOR_GEO_DATA
	offset=thread_id*EL_GEO_DAT_SIZE;
#endif

	for(i=0;i<num_geo_dofs;i++){

	  jac[1] = jac_data[i];
	  jac[2] = jac_data[num_geo_dofs+i];
	  jac[3] = jac_data[2*num_geo_dofs+i];

#ifdef USE_WORKSPACE_FOR_GEO_DATA

	  jac[4] = workspace[offset+3*i];  //node coor
	  jac[5] = workspace[offset+3*i+1];
	  jac[6] = workspace[offset+3*i+2];

#else // if not USE_WORKSPACE_FOR_GEO_DATA (geo data in registers)

	  jac[4] = geo_dat[3*i];  //node coor
	  jac[5] = geo_dat[3*i+1];
	  jac[6] = geo_dat[3*i+2];

#endif // end if not USE_GEO_DAT_WORKSPACE

	  temp1 += jac[4] * jac[1];
	  temp2 += jac[4] * jac[2];
	  temp3 += jac[4] * jac[3];
	  temp4 += jac[5] * jac[1];
	  temp5 += jac[5] * jac[2];
	  temp6 += jac[5] * jac[3];
	  temp7 += jac[6] * jac[1];
	  temp8 += jac[6] * jac[2];
	  temp9 += jac[6] * jac[3];

	}

      } // the end of scope for jac_data

      jac[0] = (temp5*temp9 - temp8*temp6);
      jac[1] = (temp8*temp3 - temp2*temp9);
      jac[2] = (temp2*temp6 - temp3*temp5);

      daux = temp1*jac[0] + temp4*jac[1] + temp7*jac[2];

      /* Jacobian calculations - |J| and inverse of the Jacobian matrix*/
      jac[9] = vol * daux; // vol = weight * det J

      faux = one/daux;

      jac[0] *= faux;
      jac[1] *= faux;
      jac[2] *= faux;

      jac[3] = (temp6*temp7 - temp4*temp9)*faux;
      jac[4] = (temp1*temp9 - temp7*temp3)*faux;
      jac[5] = (temp3*temp4 - temp1*temp6)*faux;

      jac[6] = (temp4*temp8 - temp5*temp7)*faux;
      jac[7] = (temp2*temp7 - temp1*temp8)*faux;
      jac[8] = (temp1*temp5 - temp2*temp4)*faux;

//************* THE END OF: JACOBIAN TERMS CALCULATIONS *************************//
//-------------------------------------------------------------

      __syncthreads();

#ifdef COAL_WRITE

    // write jac_data
    offset = (element_index-thread_id)*(10);

    for(i=0;i<10;i++)
    	jac_dat[offset+i*WG_SIZE_JAC+thread_id]=jac[i];

#else
    //barrier(CLK_GLOBAL_MEM_FENCE);
    __syncthreads();
    offset = (element_index)*(WG_SIZE_JAC)*10+igauss*10;
    for(i=0;i<10;i++)
     	jac_dat[offset+i]=jac[i];
//    if(group_id==0 && thread_id==79 && igauss == 0)
//    {
//    	printf("igauss=%d,wg=%d,elem_ind=%d,thread=%d,offset=%d\n",igauss,group_id,element_index,thread_id,offset);
//    	for(i=0;i<10;i++)
//    	{
//    		printf("jac[%d]=%lf\n",i,jac[i]);
//    		printf("jac_dat[%d]=%lf\n",offset+i,jac_dat[offset+i]);
//    	}
//    }

#endif // end if not COAL_WRITE

    __syncthreads();
//    barrier(CLK_GLOBAL_MEM_FENCE);
//		if(group_id==0 && thread_id==0)
//		{
//		  printf("igauss=%d,AAAjac_dat[169]=%lf\n",igauss,jac_dat[169]);
//		}

    }//igauss



  }//ielem

  //barrier(CLK_GLOBAL_MEM_FENCE);
};
